# Ghost Agent Restored
Paquete recuperado despues de eliminacion accidental.
Incluye:
- Panel de Control v7.1
- Extension.js v7.1
- Scripts de instalacion y desinstalacion
